import { GoogleGenAI } from "@google/genai";
import { PatientData, AdlLevel } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

function formatDataForPrompt(data: PatientData): string {
  const adlToString = (adl: { [key: string]: AdlLevel }) => {
    return `食事: ${adl.eating}, 排泄: ${adl.toileting}, 更衣: ${adl.dressing}, 入浴: ${adl.bathing}, 移動: ${adl.mobility}`;
  }

  return `
# 看護サマリー生成用データ

## 1. 患者基本情報
- 氏名: ${data.name}
- 年齢: ${data.age}歳
- 性別: ${data.gender}
- 入院日: ${data.admissionDate}
- 退院（転院）日: ${data.dischargeDate}
- 診断名: ${data.diagnosis}

## 2. 入院時の状況
- 入院経緯: ${data.admissionReason}
- 入院時のADL: ${adlToString(data.admissionAdl)}
- 入院時の認知機能: ${data.admissionCognition}

## 3. 治療と医学的経過
- 主要な治療内容: ${data.treatmentProgress}
- 主要な検査結果の推移: ${data.testResults}
- バイタルサインの特記すべき変動: ${data.vitalSigns}

## 4. リハビリテーションの経過
- 介入種別: ${data.rehabIntervention}
- リハビリテーションの目標と達成度: ${data.rehabGoalAchievement}
- 現在のADL: ${adlToString(data.currentAdl)}
- 使用している自助具・補装具: ${data.assistiveDevices}

## 5. 看護上の重要項目
### リスク
- 褥瘡: ${data.risks.pressureUlcer}
- 転倒・転落: ${data.risks.fallRisk}
- 嚥下機能と食事形態: ${data.risks.swallowingFunction}
### ケア
- 排泄ケア: ${data.care.toiletingCare}
- 清潔ケア: ${data.care.hygieneCare}
- コミュニケーション: ${data.care.communication}
- 認知・精神状態: ${data.care.cognitiveMentalState}
### 各種評価
- 要介護度: ${data.kaigoLevel}
- 障害高齢者の日常生活自立度: ${data.jiritsudoDisabled}
- 認知症高齢者の日常生活自立度: ${data.jiritsudoDementia}

## 6. 社会的背景と退院支援
- キーパーソンと続柄: ${data.keyPerson}
- 退院後の療養場所: ${data.dischargeLocation}
`;
}

export const generateSummary = async (data: PatientData): Promise<string> => {
  const structuredData = formatDataForPrompt(data);

  const prompt = `
あなたは、医療・看護分野の業務効率化を支援する経験豊富なAIアシスタントです。
以下の構造化された患者データに基づき、プロフェッショナルで、人間味があり、論理的で分かりやすい叙述形式の看護サマリーを日本語で作成してください。
単なる情報の羅列ではなく、患者の全体像と今後のケアのポイントが明確に伝わるように、文脈を読み取って文章を生成してください。

生成するサマリーは、必ず以下の4つのセクション構成に従い、各見出しをそのまま使用してください。
重要：出力はマークダウン形式（例: ###, **, ##）は一切含めず、プレーンテキストのみで記述してください。

【総括】: 患者の基本情報、入院経緯、主要な治療経過を簡潔にまとめる。
【ADLと機能回復】: 入院時と現在のADLを比較し、リハビリによる回復状況や残存する課題を記述する。
【看護上の問題とケアの要点】: 褥瘡、転倒、嚥下などのリスクと、それに対する具体的なケアの内容を記述する。特に注意すべき認知・精神面の状態についても言及する。
【退院に向けた申し送り事項】: 退院後の生活を見据え、家族への指導内容や、後任のケア提供者（訪問看護師や施設職員）へ申し送るべき重要な情報を記述する。

---
${structuredData}
---
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    
    // AIの応答からマークダウン記法（##, ###, **など）を念のため除去し、クリーンなテキストを保証します。
    let cleanedText = response.text.replace(/^[#*]+\s*/gm, '').replace(/\*\*/g, '');

    return cleanedText.trim();

  } catch (error) {
    console.error("Error generating summary:", error);
    if (error instanceof Error) {
        return `エラーが発生しました: ${error.message}`;
    }
    return "サマリーの生成中に不明なエラーが発生しました。";
  }
};