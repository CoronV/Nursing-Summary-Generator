import React, { useState, useEffect, useMemo } from 'react';
import Card from './ui/Card';
import { PatientData } from '../types';

// --- Icon Components ---
const LoadingIcon: React.FC = () => (
    <svg className="animate-spin h-6 w-6 text-slate-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);
const CopyIcon: React.FC<{className?: string}> = ({className}) => ( <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75" /></svg>);
const CheckIcon: React.FC<{className?: string}> = ({className}) => ( <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}><path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" /></svg>);
const PrintIcon: React.FC<{className?: string}> = ({className}) => ( <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}><path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0 1 10.56 0m-10.56 0L6 3.129M6 20.879l-.68-1.02a25.5 25.5 0 0 1-2.08-6.839L3 12.5l.68-1.02a25.5 25.5 0 0 1 2.08-6.84L6 3.129m0 17.75 6.13-9.293a1.125 1.125 0 0 0 0-1.162L6 3.129m-3 9.375h18" /></svg>);
const UserIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>;
const CakeIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h12a2 2 0 012 2v1a2 2 0 01-2 2H4a2 2 0 01-2-2V5z" /><path d="M4 11a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1z" /><path d="M2 15a2 2 0 012-2h12a2 2 0 012 2v1a2 2 0 01-2 2H4a2 2 0 01-2-2v-1z" /></svg>;
const CalendarIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>;
const InfoIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const RehabIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;
const CareIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const DischargeIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4 4 4-4m-4-5v9" /><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3" /></svg>;
const ClipboardListIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" /><path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" /></svg>;


// --- Types and Constants ---
interface SummarySectionData {
  id: string;
  title: string;
  content: string;
  icon: React.ReactNode;
}

const SECTION_DEFINITIONS: { [key: string]: { title: string; icon: React.ReactNode; } } = {
  '総括': { title: '総括', icon: <InfoIcon /> },
  'ADLと機能回復': { title: 'ADLと機能回復', icon: <RehabIcon /> },
  '看護上の問題とケアの要点': { title: '看護上の問題とケアの要点', icon: <CareIcon /> },
  '退院に向けた申し送り事項': { title: '退院に向けた申し送り事項', icon: <DischargeIcon /> },
};

// --- Helper Functions ---
const parseSummary = (summaryText: string): SummarySectionData[] => {
  const sections: SummarySectionData[] = [];
  const regex = /【([^】]+)】/g;
  const parts = summaryText.split(regex);
  if (parts.length <= 1) return summaryText ? [{ id: 'full', title: 'サマリー', content: summaryText, icon: <InfoIcon />}] : [];

  for (let i = 1; i < parts.length; i += 2) {
    const title = parts[i];
    const content = parts[i + 1]?.trim() ?? '';
    const def = SECTION_DEFINITIONS[title];
    if (def) {
      sections.push({
        id: title,
        title: def.title,
        content: content,
        icon: def.icon,
      });
    }
  }
  return sections;
};

// --- Main Component ---
interface SummaryDisplayProps {
  patientData: PatientData;
  summary: string;
  setSummary: (summary: string) => void;
  isLoading: boolean;
}

const SummaryDisplay: React.FC<SummaryDisplayProps> = ({ patientData, summary, setSummary, isLoading }) => {
  const [isCopied, setIsCopied] = useState(false);
  const [sections, setSections] = useState<SummarySectionData[]>([]);

  useEffect(() => {
    setSections(parseSummary(summary));
  }, [summary]);

  const handleContentChange = (id: string, newContent: string) => {
    const updatedSections = sections.map(sec => sec.id === id ? { ...sec, content: newContent } : sec);
    setSections(updatedSections);

    const updatedSummaryString = updatedSections.map(sec => sec.title === 'サマリー' ? sec.content : `【${sec.title}】\n${sec.content}`).join('\n\n');
    setSummary(updatedSummaryString);
  };
  
  const handleCopy = () => {
    const headerText = `患者氏名: ${patientData.name || '未入力'} 様\n` +
                       `年齢: ${patientData.age || '未入力'}歳\n` +
                       `入院日: ${patientData.admissionDate || '未入力'}\n` +
                       `退院日: ${patientData.dischargeDate || '未入力'}\n` +
                       `要介護度: ${patientData.kaigoLevel || '未設定'}\n`+
                       `障害高齢者の日常生活自立度: ${patientData.jiritsudoDisabled || '未設定'}\n`+
                       `認知症高齢者の日常生活自立度: ${patientData.jiritsudoDementia || '未設定'}\n\n`+
                       `----------------------------------------\n\n`;
    const bodyText = sections.map(sec => sec.title === 'サマリー' ? sec.content : `【${sec.title}】\n${sec.content.trim()}`).join('\n\n');
    navigator.clipboard.writeText(headerText + bodyText);
    setIsCopied(true);
  };
  
  const handlePrint = () => { window.print(); };

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  const renderPlaceholder = () => (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-slate-400 text-center">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
      <p className="mt-4 text-lg">左のフォームに入力し、</p>
      <p className="text-lg">「サマリーを生成」ボタンを押してください。</p>
    </div>
  );

  const renderLoading = () => (
    <div className="flex flex-col items-center justify-center min-h-[400px] text-slate-500">
      <LoadingIcon />
      <p className="mt-4 text-lg">AIがサマリーを生成中です...</p>
      <p className="text-sm">通常10〜20秒ほどかかります</p>
    </div>
  );
  
  return (
    <Card className="print-summary-card">
      <div className="flex justify-between items-center border-b-2 border-sky-200 pb-2 mb-6 print-hide">
        <h2 className="text-xl font-bold text-sky-700">生成された看護サマリー</h2>
        {summary && !isLoading && (
          <div className="flex items-center gap-2">
            <button onClick={handleCopy} disabled={isCopied} className="flex items-center gap-2 px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 disabled:bg-emerald-500 disabled:text-white transition-all duration-300" aria-label={isCopied ? 'Copied' : 'Copy summary'}>
              {isCopied ? <CheckIcon className="w-5 h-5" /> : <CopyIcon className="w-5 h-5" />}
              {isCopied ? 'コピーしました' : 'コピー'}
            </button>
            <button onClick={handlePrint} className="flex items-center gap-2 px-3 py-1.5 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-all duration-300" aria-label="Print summary">
              <PrintIcon className="w-5 h-5" />
              印刷
            </button>
          </div>
        )}
      </div>
      
      {isLoading ? renderLoading() : !summary ? renderPlaceholder() : (
        <div>
            {/* Print-only Title */}
            <h3 className="summary-print-title">【看護サマリー】</h3>
            
            {/* Wrapper for unified printing */}
            <div className="print-unified-frame">
                {/* Patient Info Header */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg print-patient-info">
                    <div className="flex items-center gap-3 mb-4">
                        <span className="text-slate-500"><UserIcon /></span>
                        <h3 className="text-xl font-bold text-slate-800">{patientData.name || '氏名未入力'} 様</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4 text-sm">
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><CakeIcon/></span> 年齢: <span className="font-medium text-slate-800">{patientData.age || '-'}歳</span></div>
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><CalendarIcon/></span> 入院日: <span className="font-medium text-slate-800">{patientData.admissionDate || '-'}</span></div>
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><CalendarIcon/></span> 退院日: <span className="font-medium text-slate-800">{patientData.dischargeDate || '-'}</span></div>
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><ClipboardListIcon/></span> 要介護度: <span className="font-medium text-slate-800">{patientData.kaigoLevel || '-'}</span></div>
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><ClipboardListIcon/></span> 障害自立度: <span className="font-medium text-slate-800">{patientData.jiritsudoDisabled || '-'}</span></div>
                        <div className="flex items-center gap-2 text-slate-600"><span className="text-slate-400"><ClipboardListIcon/></span> 認知症自立度: <span className="font-medium text-slate-800">{patientData.jiritsudoDementia || '-'}</span></div>
                    </div>
                </div>
              
                {/* Summary Sections */}
                <div className="space-y-4 print-sections-wrapper">
                {sections.map((section) => (
                    <div key={section.id} className="rounded-lg overflow-hidden border border-dashed border-sky-200 print-section-container">
                      <h4 className="flex items-center gap-3 font-bold p-3 bg-sky-50 text-sky-800 print-section-header">
                        <span className="flex-shrink-0">{section.icon}</span>
                        <span className="print-section-title">{section.title}</span>
                      </h4>
                      <div
                        contentEditable
                        suppressContentEditableWarning={true}
                        onBlur={(e) => handleContentChange(section.id, e.currentTarget.innerText)}
                        className="prose prose-sm max-w-none w-full p-4 bg-white whitespace-pre-wrap focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-400 print-summary-content"
                        dangerouslySetInnerHTML={{ __html: section.content.replace(/\n/g, '<br />') }}
                       />
                    </div>
                  ))}
                </div>
            </div>
        </div>
      )}
    </Card>
  );
};

export default SummaryDisplay;