import React from 'react';
import { PatientData, AdlLevel } from '../types';
import { ADL_LEVELS, GENDERS, KAIGO_LEVELS, JIRITSUDO_DISABLED_LEVELS, JIRITSUDO_DEMENTIA_LEVELS } from '../constants';
import Card from './ui/Card';
import Input from './ui/Input';
import Select from './ui/Select';
import Textarea from './ui/Textarea';

interface PatientFormProps {
  data: PatientData;
  setData: React.Dispatch<React.SetStateAction<PatientData>>;
}

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-xl font-bold text-sky-700 border-b-2 border-sky-200 pb-2 mb-6">
    {children}
  </h2>
);

const AdlInputs: React.FC<{
  adl: PatientData['admissionAdl'];
  onChange: <K extends keyof PatientData['admissionAdl']>(key: K, value: AdlLevel) => void;
  idPrefix: string;
}> = ({ adl, onChange, idPrefix }) => (
  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
    <Select
      label="食事"
      id={`${idPrefix}-eating`}
      options={ADL_LEVELS}
      value={adl.eating}
      onChange={(e) => onChange('eating', e.target.value as AdlLevel)}
    />
    <Select
      label="排泄"
      id={`${idPrefix}-toileting`}
      options={ADL_LEVELS}
      value={adl.toileting}
      onChange={(e) => onChange('toileting', e.target.value as AdlLevel)}
    />
    <Select
      label="更衣"
      id={`${idPrefix}-dressing`}
      options={ADL_LEVELS}
      value={adl.dressing}
      onChange={(e) => onChange('dressing', e.target.value as AdlLevel)}
    />
    <Select
      label="入浴"
      id={`${idPrefix}-bathing`}
      options={ADL_LEVELS}
      value={adl.bathing}
      onChange={(e) => onChange('bathing', e.target.value as AdlLevel)}
    />
    <Select
      label="移動"
      id={`${idPrefix}-mobility`}
      options={ADL_LEVELS}
      value={adl.mobility}
      onChange={(e) => onChange('mobility', e.target.value as AdlLevel)}
    />
  </div>
);

const PatientForm: React.FC<PatientFormProps> = ({ data, setData }) => {
  const handleChange = <K extends keyof PatientData>(key: K, value: PatientData[K]) => {
    setData((prev) => ({ ...prev, [key]: value }));
  };

  const handleNestedChange = <
    T extends 'admissionAdl' | 'currentAdl' | 'risks' | 'care',
    K extends keyof PatientData[T]
  >(
    topKey: T,
    nestedKey: K,
    value: PatientData[T][K]
  ) => {
    setData((prev) => ({
      ...prev,
      [topKey]: {
        ...prev[topKey],
        [nestedKey]: value,
      },
    }));
  };

  return (
    <Card>
      <form className="space-y-10">
        <section>
          <SectionTitle>1. 患者基本情報</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="氏名" id="name" value={data.name} onChange={(e) => handleChange('name', e.target.value)} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="年齢" id="age" type="number" value={data.age} onChange={(e) => handleChange('age', e.target.value)} />
              <Select label="性別" id="gender" options={GENDERS} value={data.gender} onChange={(e) => handleChange('gender', e.target.value as PatientData['gender'])} />
            </div>
            <Input label="入院日" id="admissionDate" type="date" value={data.admissionDate} onChange={(e) => handleChange('admissionDate', e.target.value)} />
            <Input label="退院(転院)日" id="dischargeDate" type="date" value={data.dischargeDate} onChange={(e) => handleChange('dischargeDate', e.target.value)} />
            <div className="md:col-span-2">
              <Input label="診断名" id="diagnosis" value={data.diagnosis} onChange={(e) => handleChange('diagnosis', e.target.value)} />
            </div>
          </div>
        </section>

        <section>
          <SectionTitle>2. 入院時の状況</SectionTitle>
          <div className="space-y-6">
            <Textarea label="入院経緯" id="admissionReason" value={data.admissionReason} onChange={(e) => handleChange('admissionReason', e.target.value)} />
            <div>
              <h3 className="text-md font-semibold text-slate-700 mb-2">入院時のADL</h3>
              <AdlInputs adl={data.admissionAdl} onChange={(key, value) => handleNestedChange('admissionAdl', key, value)} idPrefix="admission-adl" />
            </div>
            <Textarea label="入院時の認知機能 (JCS/GCS, 見当識など)" id="admissionCognition" value={data.admissionCognition} onChange={(e) => handleChange('admissionCognition', e.target.value)} />
          </div>
        </section>

        <section>
          <SectionTitle>3. 治療と医学的経過</SectionTitle>
          <div className="space-y-6">
            <Textarea label="主要な治療内容 (手術, 薬物療法など)" id="treatmentProgress" value={data.treatmentProgress} onChange={(e) => handleChange('treatmentProgress', e.target.value)} />
            <Textarea label="主要な検査結果の推移" id="testResults" value={data.testResults} onChange={(e) => handleChange('testResults', e.target.value)} />
            <Textarea label="バイタルサインの特記すべき変動" id="vitalSigns" value={data.vitalSigns} onChange={(e) => handleChange('vitalSigns', e.target.value)} />
          </div>
        </section>

        <section>
          <SectionTitle>4. リハビリテーションの経過</SectionTitle>
          <div className="space-y-6">
            <Textarea label="介入種別 (PT, OT, ST)" id="rehabIntervention" value={data.rehabIntervention} onChange={(e) => handleChange('rehabIntervention', e.target.value)} />
            <Textarea label="リハビリテーションの目標と達成度" id="rehabGoalAchievement" value={data.rehabGoalAchievement} onChange={(e) => handleChange('rehabGoalAchievement', e.target.value)} />
            <div>
              <h3 className="text-md font-semibold text-slate-700 mb-2">現在のADL</h3>
              <AdlInputs adl={data.currentAdl} onChange={(key, value) => handleNestedChange('currentAdl', key, value)} idPrefix="current-adl" />
            </div>
            <Textarea label="使用している自助具・補装具" id="assistiveDevices" value={data.assistiveDevices} onChange={(e) => handleChange('assistiveDevices', e.target.value)} />
          </div>
        </section>

        <section>
          <SectionTitle>5. 看護上の重要項目</SectionTitle>
          <div className="space-y-8">
            <div>
              <h3 className="text-lg font-semibold text-slate-700 mb-4">リスク</h3>
              <div className="space-y-6">
                <Textarea label="褥瘡の有無 (部位・深達度・処置方法)" id="pressureUlcer" value={data.risks.pressureUlcer} onChange={(e) => handleNestedChange('risks', 'pressureUlcer', e.target.value)} />
                <Textarea label="転倒・転落歴とリスク評価" id="fallRisk" value={data.risks.fallRisk} onChange={(e) => handleNestedChange('risks', 'fallRisk', e.target.value)} />
                <Textarea label="嚥下機能と食事形態" id="swallowingFunction" value={data.risks.swallowingFunction} onChange={(e) => handleNestedChange('risks', 'swallowingFunction', e.target.value)} />
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-700 mb-4">ケア</h3>
              <div className="space-y-6">
                <Textarea label="排泄ケア" id="toiletingCare" value={data.care.toiletingCare} onChange={(e) => handleNestedChange('care', 'toiletingCare', e.target.value)} />
                <Textarea label="清潔ケア" id="hygieneCare" value={data.care.hygieneCare} onChange={(e) => handleNestedChange('care', 'hygieneCare', e.target.value)} />
                <Textarea label="コミュニケーション" id="communication" value={data.care.communication} onChange={(e) => handleNestedChange('care', 'communication', e.target.value)} />
                <Textarea label="認知・精神状態" id="cognitiveMentalState" value={data.care.cognitiveMentalState} onChange={(e) => handleNestedChange('care', 'cognitiveMentalState', e.target.value)} />
              </div>
            </div>
             <div>
              <h3 className="text-lg font-semibold text-slate-700 mb-4">各種評価</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <Select label="要介護度" id="kaigoLevel" options={KAIGO_LEVELS} value={data.kaigoLevel} onChange={(e) => handleChange('kaigoLevel', e.target.value)} />
                 <Select label="障害高齢者の日常生活自立度" id="jiritsudoDisabled" options={JIRITSUDO_DISABLED_LEVELS} value={data.jiritsudoDisabled} onChange={(e) => handleChange('jiritsudoDisabled', e.target.value)} />
                 <Select label="認知症高齢者の日常生活自立度" id="jiritsudoDementia" options={JIRITSUDO_DEMENTIA_LEVELS} value={data.jiritsudoDementia} onChange={(e) => handleChange('jiritsudoDementia', e.target.value)} />
              </div>
            </div>
          </div>
        </section>
        
        <section>
          <SectionTitle>6. 社会的背景と退院支援</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="キーパーソンと続柄" id="keyPerson" value={data.keyPerson} onChange={(e) => handleChange('keyPerson', e.target.value)} />
            <Input label="退院後の療養場所" id="dischargeLocation" value={data.dischargeLocation} onChange={(e) => handleChange('dischargeLocation', e.target.value)} />
          </div>
        </section>
      </form>
    </Card>
  );
};

export default PatientForm;